SMODS.Rarity{
    key = "mythic",
	loc_txt = {},
    badge_colour = HEX("440bea"),
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.0005
}
SMODS.Rarity{
    key = "nft",
	loc_txt = {},
    badge_colour = HEX("ff3ae1"),
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.1
}